using RDatasets
iris_dataset = dataset("datasets", "iris")
head(iris_dataset)
