using DataFrames
dvector = data([1,2,3,4,5])
dmatrix = data([10 20 30; 40 50 60])
