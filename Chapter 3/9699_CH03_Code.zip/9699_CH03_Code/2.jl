using StatsBase
using RDatasets
w = WeightVec([1.,2.,3.],6.)
eltype(wv)
length(wv)
isempty(wv)
values(wv)
